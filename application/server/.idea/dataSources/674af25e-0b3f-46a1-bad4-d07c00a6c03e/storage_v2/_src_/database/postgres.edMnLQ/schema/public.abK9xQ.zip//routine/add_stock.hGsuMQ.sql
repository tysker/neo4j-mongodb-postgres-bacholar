create function add_stock(stock_name character varying) returns integer
    language plpgsql
as
$$
DECLARE
    newId INTEGER;
	BEGIN 
		INSERT INTO stocks (stockname) values(stock_name) returning id into newid;
    RETURN newId;
	END
$$;

alter function add_stock(varchar) owner to postgres;

grant execute on function add_stock(varchar) to dao;

