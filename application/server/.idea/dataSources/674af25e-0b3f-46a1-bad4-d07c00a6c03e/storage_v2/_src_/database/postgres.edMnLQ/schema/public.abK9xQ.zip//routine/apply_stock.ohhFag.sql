create function apply_stock(_email character varying, _stockname character varying) returns boolean
    language plpgsql
as
$$
DECLARE 
	did_insert boolean := false;
	stockId integer;
	userId integer;
BEGIN 
	SELECT id INTO stockId
	FROM stocks s
	WHERE s.stockname = _stockname
	LIMIT 1;

	IF stockId IS NULL THEN 
		INSERT INTO stocks (stockname)
		VALUES (_stockname) 
		RETURNING id INTO stockId;

		did_insert := true;
	END IF;
	
	IF stockId IS NOT NULL THEN
		SELECT id INTO userId 
		FROM users u
		WHERE u.email = _email;

		CALL add_user_stock(userId, stockId);
	END IF;

	RETURN did_insert;
END;
$$;

alter function apply_stock(varchar, varchar) owner to postgres;

grant execute on function apply_stock(varchar, varchar) to dao;

