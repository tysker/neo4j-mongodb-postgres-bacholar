create view view_users_keywords(user_id, keyword_id, keyword, username, email, pwd) as
SELECT users_keywords.user_id,
       users_keywords.keyword_id,
       keywords.keyword,
       users.username,
       users.email,
       users.pwd
FROM users_keywords
         JOIN keywords ON users_keywords.keyword_id = keywords.id
         JOIN users ON users_keywords.user_id = users.id;

alter table view_users_keywords
    owner to postgres;

grant select on view_users_keywords to dao;

