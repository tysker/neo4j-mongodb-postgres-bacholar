create view view_users(id, username, email, pwd) as
SELECT users.id,
       users.username,
       users.email,
       users.pwd
FROM users;

alter table view_users
    owner to postgres;

grant select on view_users to dao;

