create procedure add_user_keyword_stock(user_id integer, keyword_id integer, stock_id integer)
    language plpgsql
as
$$
BEGIN 
		INSERT INTO users_keywords_stocks (user_id, keyword_id, stock_id) values(user_id, keyword_id, stock_id);
	END
$$;

alter procedure add_user_keyword_stock(integer, integer, integer) owner to postgres;

grant execute on procedure add_user_keyword_stock(integer, integer, integer) to dao;

