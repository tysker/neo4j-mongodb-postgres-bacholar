create procedure add_user_keyword(user_id integer, keyword_id integer)
    language plpgsql
as
$$
BEGIN 
		INSERT INTO users_keywords (user_id, keyword_id) values(user_id, keyword_id);
	END
$$;

alter procedure add_user_keyword(integer, integer) owner to postgres;

grant execute on procedure add_user_keyword(integer, integer) to dao;

