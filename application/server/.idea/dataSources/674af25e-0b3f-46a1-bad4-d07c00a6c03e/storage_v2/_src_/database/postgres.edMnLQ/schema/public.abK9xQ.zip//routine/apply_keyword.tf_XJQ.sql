create function apply_keyword(_email character varying, _keyword character varying) returns boolean
    language plpgsql
as
$$
DECLARE 
	did_insert boolean := false;
	keywordId integer;
	userId integer;
BEGIN 
	SELECT id INTO keywordId
	FROM keywords k
	WHERE k.keyword = _keyword
	LIMIT 1;

	IF keywordId IS NULL THEN 
		INSERT INTO keywords (keyword)
		VALUES (_keyword) 
		RETURNING id INTO keywordId;

		did_insert := true;
	END IF;
	
	IF keywordId IS NOT NULL THEN
		SELECT id INTO userId 
		FROM users u
		WHERE u.email = _email;

		CALL add_user_keyword(userId, keywordId);
	END IF;

	RETURN did_insert;
END;
$$;

alter function apply_keyword(varchar, varchar) owner to postgres;

grant execute on function apply_keyword(varchar, varchar) to dao;

