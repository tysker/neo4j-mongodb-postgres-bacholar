create function add_keyword(keyword_name character varying) returns integer
    language plpgsql
as
$$
DECLARE
    newId INTEGER;
	BEGIN 
		INSERT INTO keywords (keyword) values(keyword_name) returning id into newid;
	RETURN newId;
	END
$$;

alter function add_keyword(varchar) owner to postgres;

grant execute on function add_keyword(varchar) to dao;

