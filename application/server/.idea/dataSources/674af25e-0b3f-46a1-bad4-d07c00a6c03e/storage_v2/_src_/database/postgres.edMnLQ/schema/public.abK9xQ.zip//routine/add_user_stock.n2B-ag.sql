create procedure add_user_stock(user_id integer, stock_id integer)
    language plpgsql
as
$$
BEGIN 
		INSERT INTO users_stocks (user_id, stock_id) values(user_id, stock_id);
	END
$$;

alter procedure add_user_stock(integer, integer) owner to postgres;

grant execute on procedure add_user_stock(integer, integer) to dao;

