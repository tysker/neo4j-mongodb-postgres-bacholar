create function user_adding_log() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO "log_users"("id", "username", "email", "db_username", "adding_time")
    VALUES(NEW."id",NEW."username",NEW."email",current_user,current_date);
RETURN NEW;
END;
$$;

alter function user_adding_log() owner to postgres;

