create function keyword_adding_log() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO "log_keywords"("id", "keyword", "db_username", "adding_time")
    VALUES(new."id",NEW."keyword",current_user,current_date);
RETURN NEW;
END;
$$;

alter function keyword_adding_log() owner to postgres;

