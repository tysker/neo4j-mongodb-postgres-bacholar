create function apply_keyword_stock(_userid integer, _keywordname character varying, _stockname character varying) returns boolean
    language plpgsql
as
$$
DECLARE 
	did_insert boolean := false;
	keywordId integer;
	userId integer :=_userId;
	stockId integer;
BEGIN 
	SELECT id INTO keywordId
	FROM keywords k
	WHERE k.keyword = _keywordName
	LIMIT 1;

	IF keywordId IS NULL THEN 
		INSERT INTO keywords (keyword)
		VALUES (_keywordName) 
		RETURNING id INTO keywordId;
		
		did_insert := true;
	END IF;

SELECT id INTO stockId
	FROM stocks s
	WHERE s.stockname = _stockName
	LIMIT 1;

	IF stockId IS NULL THEN 
		INSERT INTO stocks (stockname)
		VALUES (_stockName) 
		RETURNING id INTO stockId;
	
		did_insert := true;
	END IF;

	CALL add_user_keyword_stock(userId, keywordId, stockId);

	RETURN did_insert;
END;
$$;

alter function apply_keyword_stock(integer, varchar, varchar) owner to postgres;

grant execute on function apply_keyword_stock(integer, varchar, varchar) to dao;

