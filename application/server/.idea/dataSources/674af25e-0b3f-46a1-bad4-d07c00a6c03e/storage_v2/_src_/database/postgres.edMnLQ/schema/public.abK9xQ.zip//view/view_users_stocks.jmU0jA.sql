create view view_users_stocks(user_id, stock_id, stockname, username, email, pwd) as
SELECT users_stocks.user_id,
       users_stocks.stock_id,
       stocks.stockname,
       users.username,
       users.email,
       users.pwd
FROM users_stocks
         JOIN stocks ON users_stocks.stock_id = stocks.id
         JOIN users ON users_stocks.user_id = users.id;

alter table view_users_stocks
    owner to postgres;

grant select on view_users_stocks to dao;

