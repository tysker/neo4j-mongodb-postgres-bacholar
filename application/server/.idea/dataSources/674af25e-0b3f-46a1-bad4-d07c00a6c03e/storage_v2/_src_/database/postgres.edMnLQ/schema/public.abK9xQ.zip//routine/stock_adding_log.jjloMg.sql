create function stock_adding_log() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO "log_stocks"("id", "stockname", "db_username", "adding_time")
    VALUES(NEW."id",NEW."stockname",current_user,current_date);
RETURN NEW;
END;
$$;

alter function stock_adding_log() owner to postgres;

