create view view_users_keywords_stocks (user_id, keyword_id, stock_id, keyword, stockname, username, email, pwd) as
SELECT users_keywords_stocks.user_id,
       users_keywords_stocks.keyword_id,
       users_keywords_stocks.stock_id,
       keywords.keyword,
       stocks.stockname,
       users.username,
       users.email,
       users.pwd
FROM users_keywords_stocks
         JOIN keywords ON users_keywords_stocks.keyword_id = keywords.id
         JOIN stocks ON users_keywords_stocks.stock_id = stocks.id
         JOIN users ON users_keywords_stocks.user_id = users.id;

alter table view_users_keywords_stocks
    owner to postgres;

grant select on view_users_keywords_stocks to dao;

