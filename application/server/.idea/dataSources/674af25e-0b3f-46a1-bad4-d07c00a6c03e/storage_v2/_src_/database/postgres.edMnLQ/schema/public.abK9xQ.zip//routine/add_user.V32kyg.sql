create function add_user(username character varying, pwd character varying, email character varying) returns integer
    language plpgsql
as
$$
DECLARE
	newId INTEGER;
	BEGIN 
		INSERT INTO users (username, pwd, email) values(username, pwd, email) returning id into newid;
	RETURN newId;
	END
$$;

alter function add_user(varchar, varchar, varchar) owner to postgres;

grant execute on function add_user(varchar, varchar, varchar) to dao;

